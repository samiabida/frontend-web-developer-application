
function setUpEvents(){
	// add to cart
	var album_1 = document.getElementById("a1");
	var album_2 = document.getElementById("a2");
	var album_3 = document.getElementById("a3");
	var album_4 = document.getElementById("a4");
	var album_5 = document.getElementById("a5");
	var album_6 = document.getElementById("a6");
	var album_7 = document.getElementById("a7");
	var album_8 = document.getElementById("a8");
	var album_9 = document.getElementById("a9");

	// reference of cd
	var ref_cd1 = document.getElementById("cd1");
	var ref_cd2 = document.getElementById("cd2");
	var ref_cd3 = document.getElementById("cd3");
	var ref_cd4 = document.getElementById("cd4");
	var ref_cd5 = document.getElementById("cd5");
	var ref_cd6 = document.getElementById("cd6");
	var ref_cd7 = document.getElementById("cd7");
	var ref_cd8 = document.getElementById("cd8");
	var ref_cd9 = document.getElementById("cd9");
	
	// position in cart list
	var item_1 = document.getElementById("l1");
	var item_2 = document.getElementById("l2");
	var item_3 = document.getElementById("l3");
	var item_4 = document.getElementById("l4");
	var item_5 = document.getElementById("l5");
	var item_6 = document.getElementById("l6");
	var item_7 = document.getElementById("l7");
	var item_8 = document.getElementById("l8");
	var item_9 = document.getElementById("l9");

	// album_description
	var cd_info1 = document.getElementById("title_1");
	var cd_info2 = document.getElementById("title_2");
	var cd_info3 = document.getElementById("title_3");
	var cd_info4 = document.getElementById("title_4");
	var cd_info5 = document.getElementById("title_5");
	var cd_info6 = document.getElementById("title_6");
	var cd_info7 = document.getElementById("title_7");
	var cd_info8 = document.getElementById("title_8");
	var cd_info9 = document.getElementById("title_9");

	var count_1 = 0;
	var count_2 = 0;
	var count_3 = 0;
	var count_4 = 0;
	var count_5 = 0;
	var count_6 = 0;
	var count_7 = 0;
	var count_8 = 0;
	var count_9 = 0;

	var albums = [
	[cd_info1.innerHTML,15.00],
	[cd_info2.innerHTML,12.00],
	[cd_info3.innerHTML,13.00],
	[cd_info4.innerHTML,15.00],
	[cd_info5.innerHTML,12.00],
	[cd_info6.innerHTML,13.00],
	[cd_info7.innerHTML,15.00],
	[cd_info8.innerHTML,12.00],
	[cd_info9.innerHTML,13.00]
	];

	var total_price = document.getElementById("total");

	album_1.onclick = function(){
		count_1 += 1;
		album_1.innerHTML = "Add to cart " + "*" + count_1;
		// add to the total
		total_price.value = (count_1 * albums[0][1]) + (count_2 * albums[1][1]) + (count_3 * albums[2][1]) + (count_4 * albums[3][1]) + (count_5 * albums[4][1]) + (count_6 * albums[5][1]) + (count_7 * albums[6][1]) + (count_8 * albums[7][1]) + (count_9 * albums[8][1]);
	}

	album_2.onclick = function(){
		count_2 += 1;
		album_2.innerHTML = "Add to cart " + "*" + count_2;
		total_price.value = (count_1 * albums[0][1]) + (count_2 * albums[1][1]) + (count_3 * albums[2][1]) + (count_4 * albums[3][1]) + (count_5 * albums[4][1]) + (count_6 * albums[5][1]) + (count_7 * albums[6][1]) + (count_8 * albums[7][1]) + (count_9 * albums[8][1]);
	}

	album_3.onclick = function(){
		count_3 += 1;
		album_3.innerHTML = "Add to cart " + "*" + count_3;
		total_price.value = (count_1 * albums[0][1]) + (count_2 * albums[1][1]) + (count_3 * albums[2][1]) + (count_4 * albums[3][1]) + (count_5 * albums[4][1]) + (count_6 * albums[5][1]) + (count_7 * albums[6][1]) + (count_8 * albums[7][1]) + (count_9 * albums[8][1]);
	}
/*
	album_4.onclick = function(){
		count_4 += 1;
		album_4.innerHTML = "Add to cart " + "*" + count_4;
		total_price.value = (count_1 * albums[0][1]) + (count_2 * albums[1][1]) + (count_3 * albums[2][1]) + (count_4 * albums[3][1]) + (count_5 * albums[4][1]) + (count_6 * albums[5][1]) + (count_7 * albums[6][1]) + (count_8 * albums[7][1]) + (count_9 * albums[8][1]);
	}

	album_5.onclick = function(){
		count_5 += 1;
		album_5.innerHTML = "Add to cart " + "*" + count_5;
		total_price.value = (count_1 * albums[0][1]) + (count_2 * albums[1][1]) + (count_3 * albums[2][1]) + (count_4 * albums[3][1]) + (count_5 * albums[4][1]) + (count_6 * albums[5][1]) + (count_7 * albums[6][1]) + (count_8 * albums[7][1]) + (count_9 * albums[8][1]);
	}

	album_6.onclick = function(){
		count_6 += 1;
		album_6.innerHTML = "Add to cart " + "*" + count_6;
		total_price.value = (count_1 * albums[0][1]) + (count_2 * albums[1][1]) + (count_3 * albums[2][1]) + (count_4 * albums[3][1]) + (count_5 * albums[4][1]) + (count_6 * albums[5][1]) + (count_7 * albums[6][1]) + (count_8 * albums[7][1]) + (count_9 * albums[8][1]);
	}

	album_7.onclick = function(){
		count_7 += 1;
		album_7.innerHTML = "Add to cart " + "*" + count_7;
		total_price.value = (count_1 * albums[0][1]) + (count_2 * albums[1][1]) + (count_3 * albums[2][1]) + (count_4 * albums[3][1]) + (count_5 * albums[4][1]) + (count_6 * albums[5][1]) + (count_7 * albums[6][1]) + (count_8 * albums[7][1]) + (count_9 * albums[8][1]);
	}

	album_8.onclick = function(){
		count_8 += 1;
		album_8.innerHTML = "Add to cart " + "*" + count_8;
		total_price.value = (count_1 * albums[0][1]) + (count_2 * albums[1][1]) + (count_3 * albums[2][1]) + (count_4 * albums[3][1]) + (count_5 * albums[4][1]) + (count_6 * albums[5][1]) + (count_7 * albums[6][1]) + (count_8 * albums[7][1]) + (count_9 * albums[8][1]);
	}

	album_9.onclick = function(){
		count_9 += 1;
		album_9.innerHTML = "Add to cart " + "*" + count_9;
		total_price.value = (count_1 * albums[0][1]) + (count_2 * albums[1][1]) + (count_3 * albums[2][1]) + (count_4 * albums[3][1]) + (count_5 * albums[4][1]) + (count_6 * albums[5][1]) + (count_7 * albums[6][1]) + (count_8 * albums[7][1]) + (count_9 * albums[8][1]);
	}
*/
	
	var name = 0;
	var price = 1;

	var items_in_cart = document.getElementById("in_cart");
	var cart = "<tr><td><img width='50px' height='50px' src='albums/cart.jpg'></a></td><td>Price</td></tr>";

	// create the cart array
	for(var i=0; i<albums.length; i++){
		item = albums[i];
		row = "<tr>"
		+ "<td>" + item[name] + "</td>"
		+ "<td>" + item[price].toFixed(2) + "</td>"
		+ "<tr>";
		cart += row;
	}

	items_in_cart.innerHTML = cart;

}

window.onload = function(){
	
	// launch events when HTML file is loaded
	setUpEvents();
}


