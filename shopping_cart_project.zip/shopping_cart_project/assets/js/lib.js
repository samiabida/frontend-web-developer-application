
function setUpEvents(){

	$(".add-to-cart").click(function(event){
		event.preventDefault();
		var name = $(this).attr("data-name");
		var price = Number($(this).attr("data-price"));

		shopping_Cart.add_item_to_cart(name, price, 1);
		display_cart();
	});

	// cart is empty by clicking the 'clear cart' button
	$("#clear-cart").click(function(event){
		shopping_Cart.clear_cart();
		display_cart();
	});

	// display the quantity, the value of each items added in the cart
	function display_cart(){
		var cart_array = shopping_Cart.list_cart();
		var output = "";

		for (var i in cart_array){
			output += "<li>"
			+ cart_array[i].name
			+ " <input class='item-count' type='number' data-name='"
			+ cart_array[i].name
			+"' value='" + cart_array[i].quantity + "' >"
			+ " x  $" + cart_array[i].price
			+" =  $" + cart_array[i].total 
			+" <button class='plus-item' data-name='"
			+cart_array[i].name+"'>+</button>"
			+" <button class='subtract-item' data-name='"
			+cart_array[i].name+"'>-</button>"
			+" <button class='delete-items' data-name='"
			+cart_array[i].name+"'>Delete</button>"
			"</li>";
		}
		$("#show-cart").html(output);
		$("#count-cart").html( shopping_Cart.count_cart() );		
		$("#total-cart").html( shopping_Cart.total_price() );
	}

	// while the cart is empty, the delete button doesn't exist
	// by clicking Delete button, all of the items with 'data_name' are removed
	$("#show-cart").on("click", ".delete-items", function(event){
		var name = $(this).attr("data-name");
		shopping_Cart.remove_all_items_with_name(name);
		display_cart();
	});

	// button - : delete an item from cart
	$("#show-cart").on("click", ".subtract-item", function(event){
		var name = $(this).attr("data-name");
		shopping_Cart.remove_item_from_cart(name);
		display_cart();
	});

	// button + : add an item in the cart
	$("#show-cart").on("click", ".plus-item", function(event){
		var name = $(this).attr("data-name");
		shopping_Cart.add_item_to_cart(name, 0, 1);
		display_cart();
	});

	$("#show-cart").on("change", ".item-count", function(event){
		var name = $(this).attr("data-name");
		var quantity = Number( $(this).val() );
		shopping_Cart.setCountForItem(name, quantity);	
		display_cart();
	});

	// ***************
	// shopping cart objects and functions

	// create the item object
	var shopping_Cart = {};
	shopping_Cart.cart = [];
	shopping_Cart.Items = function(name, price, quantity){
		this.name = name
		this.price = price
		this.quantity = quantity
	};

	shopping_Cart.add_item_to_cart = function(name, price, quantity){
		// increment quantity when the item is added twice (at least) 
		for (var i in this.cart){
			if (this.cart[i].name === name){
				this.cart[i].quantity += quantity;
				this.save_cart();
				return;
			}
		}
		var item = new this.Items(name, price, quantity);
		this.cart.push(item);
		this.save_cart();
	};

	shopping_Cart.setCountForItem = function(name, quantity){
		for (var i in this.cart){
			if (this.cart[i].name === name){
				this.cart[i].quantity = quantity;
				break;
			}
		}
		this.save_cart();
	};	

	shopping_Cart.remove_item_from_cart = function(name){
		for (var i in this.cart){
			if (this.cart[i].name === name){
				this.cart[i].quantity --;
				if (this.cart[i].quantity === 0){
					 this.cart.splice(i, 1);
				}
				break;
			}
		}
		this.save_cart();
	};

	// remove all the items
	shopping_Cart.remove_all_items_with_name = function(name){
		for (var i in this.cart){
			if (this.cart[i].name === name){
				this.cart.splice(i, 1);
				break;
			}
		}
		this.save_cart();
	};

	// remove all the items in the cart
	shopping_Cart.clear_cart = function(){
		this.cart = [];
		this.save_cart();
	};

	// count total items in the cart 
	shopping_Cart.count_cart = function(){
		var number_items = 0;
		for (var i in this.cart){
			number_items += this.cart[i].quantity;
		}
		return number_items;
	};

	// count the total_price
	shopping_Cart.total_price = function(){
		var final_price = 0;
		for (var i in this.cart){
			final_price += this.cart[i].price * this.cart[i].quantity;
		}
		return final_price.toFixed(2);
	};

	// display cart copy of the original cart array
	shopping_Cart.list_cart = function(){
		var cart_copy = [];
		for (var i in this.cart){
			var item = this.cart[i];
			var item_copy = {};
			for (var property in item){
				item_copy[property] = item[property];
			}
			item_copy.total = (item.price * item.quantity).toFixed(2);
			cart_copy.push(item_copy);
		}
		return cart_copy ;
	};

	// save_cart array 
	shopping_Cart.save_cart = function(){
		 localStorage.setItem("shopping_cart", JSON.stringify(this.cart)); // convert cart into a string
	};

	// load_cart
	shopping_Cart.load_cart = function(){
		this.cart = JSON.parse(localStorage.getItem("shopping_cart"));
	};

	shopping_Cart.load_cart();
	display_cart();

	console.log("Shopping Cart: cart");
	console.log(shopping_Cart.cart);
	// console.log("Global Cart:");
	// console.log(cart);
}

window.onload = function(){
	
	// launch events when HTML file is loaded
	setUpEvents();
}


