# Here is the application I made in order to show my JS and HTML skills.

I create two HTML files :
- index.html : the main page of the site
- store_products.html : You will see all the albums you can add to your shopping cart